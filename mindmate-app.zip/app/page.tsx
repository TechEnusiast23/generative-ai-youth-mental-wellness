"use client"

import { useState } from "react"
import { WelcomeScreen } from "@/components/welcome-screen"
import { ChatInterface } from "@/components/chat-interface"
import { MoodTracker } from "@/components/mood-tracker"
import { ResourcesPage } from "@/components/resources-page"
import { ProfilePage } from "@/components/profile-page"
import { Navigation } from "@/components/navigation"

export default function MindMateApp() {
  const [currentScreen, setCurrentScreen] = useState<"welcome" | "chat" | "mood" | "resources" | "profile">("welcome")

  if (currentScreen === "welcome") {
    return <WelcomeScreen onGetStarted={() => setCurrentScreen("chat")} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-green-50 to-purple-50">
      <div className="max-w-md mx-auto bg-background min-h-screen shadow-xl">
        {currentScreen === "chat" && <ChatInterface />}
        {currentScreen === "mood" && <MoodTracker />}
        {currentScreen === "resources" && <ResourcesPage />}
        {currentScreen === "profile" && <ProfilePage />}

        <Navigation currentScreen={currentScreen} onScreenChange={setCurrentScreen} />
      </div>
    </div>
  )
}
