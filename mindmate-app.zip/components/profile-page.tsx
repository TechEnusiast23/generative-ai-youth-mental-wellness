"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { User, Shield, Trash2, Award } from "lucide-react"

export function ProfilePage() {
  const [notifications, setNotifications] = useState(true)
  const [darkMode, setDarkMode] = useState(false)
  const [dataSharing, setDataSharing] = useState(false)

  const achievements = [
    { name: "First Chat", description: "Started your first conversation", earned: true },
    { name: "Mood Tracker", description: "Logged mood for 7 days", earned: true },
    { name: "Resource Explorer", description: "Viewed 5 resources", earned: false },
    { name: "Wellness Warrior", description: "Used app for 30 days", earned: false },
  ]

  return (
    <div className="p-4 space-y-6 pb-20">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
          <User className="w-10 h-10 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Your Profile</h1>
          <p className="text-muted-foreground">Manage your wellness journey</p>
        </div>
      </div>

      {/* Achievements */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-primary" />
            <span>Achievements</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {achievements.map((achievement, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  achievement.earned ? "bg-primary text-primary-foreground" : "bg-muted"
                }`}
              >
                <Award className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h3 className={`font-medium ${achievement.earned ? "text-foreground" : "text-muted-foreground"}`}>
                  {achievement.name}
                </h3>
                <p className="text-sm text-muted-foreground">{achievement.description}</p>
              </div>
              {achievement.earned && <Badge className="bg-primary/10 text-primary border-primary/20">Earned</Badge>}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Privacy & Settings */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-primary" />
            <span>Privacy & Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="font-medium">Push Notifications</h3>
              <p className="text-sm text-muted-foreground">Get reminders and wellness tips</p>
            </div>
            <Switch checked={notifications} onCheckedChange={setNotifications} />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="font-medium">Dark Mode</h3>
              <p className="text-sm text-muted-foreground">Switch to dark theme</p>
            </div>
            <Switch checked={darkMode} onCheckedChange={setDarkMode} />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="font-medium">Anonymous Data Sharing</h3>
              <p className="text-sm text-muted-foreground">Help improve MindMate (optional)</p>
            </div>
            <Switch checked={dataSharing} onCheckedChange={setDataSharing} />
          </div>
        </CardContent>
      </Card>

      {/* Confidentiality Notice */}
      <Card className="shadow-sm bg-primary/5 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Shield className="w-5 h-5 text-primary mt-0.5" />
            <div className="space-y-2">
              <h3 className="font-semibold text-primary">Your Privacy Matters</h3>
              <p className="text-sm text-muted-foreground">
                All conversations are encrypted and confidential. We never share your personal information without your
                explicit consent. Your mental health journey is private and secure.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Data Management</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" className="w-full justify-start bg-transparent">
            Export My Data
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start text-destructive hover:text-destructive bg-transparent"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete All Data
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
