"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Calendar, TrendingUp } from "lucide-react"

const moodEmojis = [
  { emoji: "😢", label: "Very Sad", value: 1, color: "text-red-500" },
  { emoji: "😔", label: "Sad", value: 2, color: "text-orange-500" },
  { emoji: "😐", label: "Neutral", value: 3, color: "text-yellow-500" },
  { emoji: "😊", label: "Happy", value: 4, color: "text-green-500" },
  { emoji: "😄", label: "Very Happy", value: 5, color: "text-emerald-500" },
]

const weeklyMoods = [
  { day: "Mon", mood: 3 },
  { day: "Tue", mood: 4 },
  { day: "Wed", mood: 2 },
  { day: "Thu", mood: 4 },
  { day: "Fri", mood: 5 },
  { day: "Sat", mood: 4 },
  { day: "Sun", mood: 3 },
]

export function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<number | null>(null)
  const [todayMoodLogged, setTodayMoodLogged] = useState(false)

  const handleMoodSelect = (moodValue: number) => {
    setSelectedMood(moodValue)
    setTodayMoodLogged(true)
  }

  const averageMood = weeklyMoods.reduce((sum, day) => sum + day.mood, 0) / weeklyMoods.length

  return (
    <div className="p-4 space-y-6 pb-20">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-foreground">Mood Tracker</h1>
        <p className="text-muted-foreground">How are you feeling today?</p>
      </div>

      {/* Today's Mood */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span>Today's Mood</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!todayMoodLogged ? (
            <>
              <div className="grid grid-cols-5 gap-2">
                {moodEmojis.map((mood) => (
                  <Button
                    key={mood.value}
                    variant={selectedMood === mood.value ? "default" : "outline"}
                    className="h-16 flex flex-col space-y-1 rounded-xl"
                    onClick={() => handleMoodSelect(mood.value)}
                  >
                    <span className="text-2xl">{mood.emoji}</span>
                    <span className="text-xs">{mood.label}</span>
                  </Button>
                ))}
              </div>
              {selectedMood && (
                <p className="text-center text-sm text-muted-foreground">
                  Mood logged! Keep tracking to see your patterns.
                </p>
              )}
            </>
          ) : (
            <div className="text-center space-y-2">
              <div className="text-4xl">😊</div>
              <p className="font-medium">Mood logged for today!</p>
              <p className="text-sm text-muted-foreground">Come back tomorrow to track your mood</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Weekly Overview */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            <span>This Week</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Average Mood</span>
            <span className="font-semibold">{averageMood.toFixed(1)}/5</span>
          </div>
          <Progress value={(averageMood / 5) * 100} className="h-2" />

          <div className="grid grid-cols-7 gap-2 mt-4">
            {weeklyMoods.map((day, index) => (
              <div key={index} className="text-center space-y-2">
                <div className="text-xs text-muted-foreground">{day.day}</div>
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <span className="text-lg">{moodEmojis[day.mood - 1].emoji}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Insights */}
      <Card className="shadow-sm bg-gradient-to-r from-primary/5 to-secondary/5">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-2">💡 Insight</h3>
          <p className="text-sm text-muted-foreground">
            Your mood has been trending upward this week! Keep up the positive momentum.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
