"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Heart, Shield, Users } from "lucide-react"

interface WelcomeScreenProps {
  onGetStarted: () => void
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-green-100 to-purple-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto shadow-lg">
            <Heart className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="text-4xl font-bold text-foreground">MindMate</h1>
          <p className="text-xl text-muted-foreground font-medium">Generative AI for Youth Mental Wellness</p>
          <p className="text-lg text-muted-foreground text-balance">
            Your safe space for mental wellness support and guidance
          </p>
        </div>

        <div className="space-y-4">
          <Card className="p-6 bg-card/80 backdrop-blur-sm border-0 shadow-lg">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-card-foreground">Safe & Confidential</h3>
                <p className="text-sm text-muted-foreground">Your privacy is our priority</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card/80 backdrop-blur-sm border-0 shadow-lg">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <h3 className="font-semibold text-card-foreground">24/7 Support</h3>
                <p className="text-sm text-muted-foreground">Always here when you need us</p>
              </div>
            </div>
          </Card>
        </div>

        <Button
          onClick={onGetStarted}
          className="w-full py-6 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
          size="lg"
        >
          Get Started
        </Button>

        <p className="text-center text-sm text-muted-foreground">
          By continuing, you agree to our privacy policy and terms of service
        </p>
      </div>
    </div>
  )
}
