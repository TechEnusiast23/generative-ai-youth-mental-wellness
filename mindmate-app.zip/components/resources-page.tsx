import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Phone, Video, Headphones, ExternalLink } from "lucide-react"

const resources = [
  {
    id: 1,
    title: "Understanding Anxiety",
    description: "Learn about anxiety symptoms and coping strategies",
    type: "Article",
    icon: BookOpen,
    category: "Mental Health",
    readTime: "5 min read",
  },
  {
    id: 2,
    title: "Breathing Exercises",
    description: "Guided breathing techniques for stress relief",
    type: "Exercise",
    icon: Headphones,
    category: "Wellness",
    readTime: "10 min",
  },
  {
    id: 3,
    title: "Sleep Better Tonight",
    description: "Tips and techniques for improving sleep quality",
    type: "Video",
    icon: Video,
    category: "Self-Care",
    readTime: "8 min watch",
  },
  {
    id: 4,
    title: "Building Self-Esteem",
    description: "Practical ways to boost confidence and self-worth",
    type: "Article",
    icon: BookOpen,
    category: "Personal Growth",
    readTime: "7 min read",
  },
]

const helplines = [
  {
    name: "Crisis Text Line",
    number: "Text HOME to 741741",
    description: "24/7 crisis support via text message",
    available: "24/7",
  },
  {
    name: "National Suicide Prevention Lifeline",
    number: "988",
    description: "Free and confidential emotional support",
    available: "24/7",
  },
  {
    name: "Teen Line",
    number: "1-800-852-8336",
    description: "Teens helping teens through difficult times",
    available: "6 PM - 10 PM PST",
  },
]

export function ResourcesPage() {
  return (
    <div className="p-4 space-y-6 pb-20">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-foreground">Resources</h1>
        <p className="text-muted-foreground">Tools and support for your wellness journey</p>
      </div>

      {/* Emergency Help */}
      <Card className="shadow-sm border-destructive/20 bg-destructive/5">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-destructive">
            <Phone className="w-5 h-5" />
            <span>Need Immediate Help?</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            If you're in crisis or having thoughts of self-harm, please reach out immediately:
          </p>
          <Button className="w-full bg-destructive hover:bg-destructive/90">
            <Phone className="w-4 h-4 mr-2" />
            Call 988 - Crisis Lifeline
          </Button>
        </CardContent>
      </Card>

      {/* Self-Help Resources */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-foreground">Self-Help Resources</h2>
        <div className="grid gap-4">
          {resources.map((resource) => {
            const IconComponent = resource.icon
            return (
              <Card key={resource.id} className="shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <IconComponent className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 space-y-2">
                      <div className="flex items-start justify-between">
                        <h3 className="font-semibold text-card-foreground">{resource.title}</h3>
                        <ExternalLink className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <p className="text-sm text-muted-foreground">{resource.description}</p>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="text-xs">
                          {resource.category}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{resource.readTime}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Helplines */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-foreground">Support Helplines</h2>
        <div className="space-y-3">
          {helplines.map((helpline, index) => (
            <Card key={index} className="shadow-sm">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-card-foreground">{helpline.name}</h3>
                    <Badge variant="outline" className="text-xs">
                      {helpline.available}
                    </Badge>
                  </div>
                  <p className="text-sm font-mono text-primary">{helpline.number}</p>
                  <p className="text-sm text-muted-foreground">{helpline.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
