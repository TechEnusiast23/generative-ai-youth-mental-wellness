"use client"

import { Button } from "@/components/ui/button"
import { MessageCircle, BarChart3, BookOpen, User } from "lucide-react"

interface NavigationProps {
  currentScreen: "chat" | "mood" | "resources" | "profile"
  onScreenChange: (screen: "chat" | "mood" | "resources" | "profile") => void
}

export function Navigation({ currentScreen, onScreenChange }: NavigationProps) {
  const navItems = [
    { id: "chat" as const, icon: MessageCircle, label: "Chat" },
    { id: "mood" as const, icon: BarChart3, label: "Mood" },
    { id: "resources" as const, icon: BookOpen, label: "Resources" },
    { id: "profile" as const, icon: User, label: "Profile" },
  ]

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-background border-t border-border">
      <div className="flex items-center justify-around p-2">
        {navItems.map((item) => {
          const IconComponent = item.icon
          const isActive = currentScreen === item.id

          return (
            <Button
              key={item.id}
              variant={isActive ? "default" : "ghost"}
              size="sm"
              className={`flex-1 flex flex-col items-center space-y-1 h-auto py-2 ${
                isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
              onClick={() => onScreenChange(item.id)}
            >
              <IconComponent className="w-5 h-5" />
              <span className="text-xs">{item.label}</span>
            </Button>
          )
        })}
      </div>
    </div>
  )
}
